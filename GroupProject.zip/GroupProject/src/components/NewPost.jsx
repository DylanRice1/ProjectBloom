import React, { useState } from 'react';

function NewPost() {

  // Define state variables to store form input values
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [location, setLocation] = useState('');
  const [endDate, setEndDate] = useState('');
  const [positions, setPositions] = useState('');
  const [type, setType] = useState('');

  // Function to handle form submission
  const handleSubmit = (e) => {
    e.preventDefault(); // Prevent default form submission behavior
    
    let formData = new FormData()
    formData.append('title', title)
    formData.append('description', description)
    formData.append('location', location)
    formData.append('endDate', endDate)
    formData.append('positions', positions)
    formData.append('type', type)

    fetch('https://w20016240.nuwebspace.co.uk/groupwork/testapi/newpost',
        {
          method: 'POST',
          body: formData,
        }
    )

    .then(res => {
      if ((res.status === 200) || (res.status === 204)) {
        console.log("New Post Success")
        console.log([title, description, location, endDate, positions, type])
      } else {
        throw new Error("Error: " + res.status)
      }
    })

    .catch(error => {
      console.error("New Post Error:", error);
    })

    // Reset the form fields after submission
    setTitle('');
    setDescription('');
    setLocation('');
    setEndDate('');
    setPositions('');
    setType('');
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">New Post</h1>
      <div className="border rounded-md p-6">
        <form onSubmit={handleSubmit} className="mt-8 mx-auto max-w-md">
          <div className="mb-4">
            <label htmlFor="title" className="block text-gray-700">Project Name:</label>
            <input type="text" id="title" value={title} onChange={(e) => setTitle(e.target.value)} className="form-input mt-1 block w-full border" required/>
          </div>
          <div className="mb-4">
            <label htmlFor="description" className="block text-gray-700">Description:</label>
            <textarea id="description" value={description} onChange={(e) => setDescription(e.target.value)} className="form-textarea mt-1 block w-full border" required />
          </div>
          <div className="mb-4">
            <label htmlFor="location" className="block text-gray-700">Location:</label>
            <input type="text" id="location" value={location} onChange={(e) => setLocation(e.target.value)} className="form-input mt-1 block w-full border" required/>
          </div>
          <div className="mb-4">
            <label htmlFor="endDate" className="block text-gray-700">End Date:</label>
            <input type="date" id="endDate" value={endDate} onChange={(e) => setEndDate(e.target.value)} className="form-input mt-1 block w-full border" required/>
          </div>
          <div className="mb-4">
            <label htmlFor="positions" className="block text-gray-700">Number of Positions:</label>
            <input type="number" id="positions" value={positions} onChange={(e) => setPositions(e.target.value)} className="form-input mt-1 block w-full border" required/>
          </div>
          <div className="mb-4">
            <label htmlFor="type" className="block text-gray-700">Project Type:</label>
            <select id="type" value={type} onChange={(e) => setType(e.target.value)} className="form-select mt-1 block w-full border" required>
              <option value="">Select Project Type</option>
              <option value="Private Garden">Private Garden</option>
              <option value="Garden Centre">Garden Centre</option>
              <option value="Community Garden">Community Garden</option>
            </select>
          </div>
          <button type="submit" className="bg-green-500 text-white py-2 px-4 rounded hover:bg-green-600">Submit</button>
        </form>
      </div>
    </div>
  );
}

export default NewPost;