import React from 'react';

export const titleText = {
    fontSize: '22px',
    fontWeight: 'bold',
    fontFamily: 'sora',
    color: 'white',
};

export const navText = {
    fontSize: '15px',
    fontFamily: 'sora',
    color: 'white',

};